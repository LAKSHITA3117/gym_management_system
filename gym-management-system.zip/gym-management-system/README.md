# FitFlow — Gym Management System

A responsive front-end gym management project built with HTML, CSS and vanilla JavaScript.

## Features
- Admin dashboard: total members, active memberships, daily check-ins and revenue
- Member registration and searchable directory
- Monthly, quarterly and yearly membership plans
- Membership expiry tracking and renewals
- Attendance check-in with duplicate same-day check-in prevention
- Revenue and membership reports
- CSV export of member records
- Browser localStorage persistence

## Run locally
1. Extract `gym-management-system.zip`.
2. Open the folder in Visual Studio Code.
3. Open `index.html`.
4. Right-click and select **Open with Live Server** (install the Live Server extension if needed).
5. Or open `index.html` directly in a modern browser.

No package installation or build step is required.

## Demo plans
- Monthly: 30 days — ₹999
- Quarterly: 90 days — ₹2,499
- Yearly: 365 days — ₹8,999

Edit the `PLANS` array near the top of `script.js` to customize plans.

## Project synopsis
**Objective:** Build a web-based gym management system to register members, manage memberships, track attendance and monitor membership revenue.

**Modules:** Admin dashboard, member management, membership plans, attendance, renewals and reports.

**Technologies:** HTML5, CSS3, JavaScript and browser localStorage.

## Limitations
This is an academic/demo front-end project. Data is stored only in the current browser and is not shared across devices. It has no admin authentication, backend database, real payment processing, trainer scheduling or biometric attendance. A production system should add a secure backend, database, authentication and server-side validation.
